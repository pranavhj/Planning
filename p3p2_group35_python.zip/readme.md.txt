Dependencies- OpenCV

Please keep halfplane.py in the same directory as Astar rigid.py to run the code

Please read instructions about what to enter when you run the code carefully, or the code will fail.

Runtime for start co-ordinates-(50,30,60)  goal-cordinates-(150,150) radius-1 clearance-1 step_size-1 is about 25mins

To look at the visulaziation of the paths, increase the step_size to 10 to properly see the explored and visited paths

White region represents the region which is explored but not visited

Blue region represents the region which is visited

Red region represents the path

Command to run the code
python3 Astar rigid.py

